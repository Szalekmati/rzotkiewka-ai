# 🫜 RZOTKIEWKA AI – Global Data 2.3

## Co dokładnie robimy?

Moduł buduje **osobną, badawczą bazę zakończonych spotkań**, korzystając z
[OpenFootball / football.json](https://github.com/openfootball/football.json)
(public domain, CC0-1.0). **Nie podmienia** istniejącego `forecast_engine.py`,
`predictions.json`, żadnego backtestu ani strony `index.html`.

Wpisy mają nazwę ligi, sezon, datę, zespoły, wynik końcowy oraz ślad pochodzenia:
ścieżkę i identyfikator wersji źródłowego pliku GitHub. Program pobiera
**wszystkie** dostępne pliki ligowe z sześciu folderów sezonowych:
`2024-25`, `2025-26`, `2026-27`, `2024`, `2025`, `2026`.
Nie zakładamy, że każdy kraj i liga występują w każdym sezonie.

## Instalacja przez GitHub na Androidzie

1. Rozpakuj ZIP na telefonie.
2. W repozytorium GitHub (gałąź `main`) dodaj plik `research_leagues.py` **do katalogu głównego**.
3. W katalogu `tests` dodaj plik `test_research_leagues.py` (w razie potrzeby utwórz katalog).
4. W katalogu `.github/workflows` dodaj plik `research_leagues.yml`.
5. Wejdź do zakładki **Actions → RZOTKIEWKA – globalne ligi (baza badawcza) → Run workflow**.
6. Po zielonym wykonaniu sprawdź nowe pliki w katalogu `data`: `research_matches.csv`, `research_leagues.json` i `research_sources.json`.

**Ważne:** Zawartości paczki nie umieszczaj jako ZIP bez rozpakowania w repozytorium.
GitHub Actions potrzebuje wskazanych plików w dokładnych ścieżkach.

## Źródła, kontrola jakości i ograniczenia

- Wszystkie pobrania odbywają się z repozytorium **openfootball/football.json**.
- Wybieramy wyłącznie ligowe nazwy plików, np. `en.1.json`, `br.1.json`;
  pomijamy kopie `-full.json` i puchary, żeby nie dublować meczów.
- Program kontroluje nieprawidłowe wyniki, duplikaty i niekompletną listę źródeł.
- Nieprzeprowadzony lub błędny import nie zastępuje dotychczasowej bazy.
- Wykluczamy mecze z bieżącego dnia i przyszłości, nawet jeśli w źródle pojawia się wynik.
- Pliki bazowe nie zapewniają gwarantowanych chwil publikacji wyników i historii
  wartości *as of* przed rozpoczęciem meczu. Ten import **nie uprawnia** do
  backtestów bez wycieku informacji ani do twierdzeń o zarobku z typowania.
- Źródło może mieć luki i opóźnienia; `research_leagues.json` pokazuje, które
  rozgrywki realnie dostały dane, a które jeszcze nie.
- Harmonogram: poniedziałki 03:26 UTC oraz ręcznie przez **Run workflow**.
- Brak API key i pakietów `pip` — wyłącznie Python 3.12.
- GitHub API bez uwierzytelnienia ma limity; w przypadku błędu workflow
  zakończy się niepowodzeniem **bez** zatwierdzenia nowych danych.

## Kolejny krok

Po zebraniu bazy wykonujemy audyt jakości i porównujemy **chronologicznie**
prognozy każdego modelu z naiwną prognozą bazową, nie mieszając lig i nie
ucząc modelu na wynikach przyszłych spotkań. Rozgrywki spoza źródła, w tym
Ekstraklasę, obsłużymy dopiero po zweryfikowaniu dodatkowego legalnego źródła.

Projekt może planować ofertę Premium, ale licencje każdej kolejnej bazy danych,
zwłaszcza kursów bukmacherskich, należy sprawdzić osobno.
