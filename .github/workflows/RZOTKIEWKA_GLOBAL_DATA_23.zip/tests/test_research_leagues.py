import datetime
import unittest
from unittest.mock import patch

import research_leagues as r


class LeagueImportTests(unittest.TestCase):
    def test_finds_multiple_leagues_and_ignores_full_duplicates(self):
        nodes = {'tree': [
            {'type': 'blob', 'path': '2025-26/en.1.json', 'sha': 'abc'},
            {'type': 'blob', 'path': '2025-26/en.1-full.json', 'sha': 'dup'},
            {'type': 'blob', 'path': '2026/br.1.json', 'sha': 'def'},
            {'type': 'blob', 'path': '2025-26/README.md', 'sha': 'no'},
        ]}
        found = r.discover(nodes)
        self.assertEqual([x['path'] for x in found], ['2025-26/en.1.json', '2026/br.1.json'])

    def test_rejects_truncated_list(self):
        with self.assertRaises(ValueError):
            r.discover({'truncated': True, 'tree': []})

    def test_normalizes_ft_array_and_dict_and_ignores_future(self):
        node = {'path': '2025-26/en.1.json', 'season': '2025-26', 'league': 'en.1', 'sha': 'abc'}
        doc = {'name': 'Premier League', 'matches': [
            {'date': '2025-10-01', 'team1': 'A FC', 'team2': 'B FC', 'score': {'ft': [2, 1]}},
            {'date': '2025-10-02', 'team1': 'B FC', 'team2': 'C FC', 'score': [0, 0]},
            {'date': '2025-10-04', 'team1': 'C FC', 'team2': 'A FC'},
            {'date': '2026-12-01', 'team1': 'C FC', 'team2': 'B FC', 'score': [1, 0]},
        ]}
        rows, meta = r.normalize(node, doc, today=datetime.date(2026, 11, 8))
        self.assertEqual(len(rows), 2)
        self.assertEqual([x['outcome'] for x in rows], ['1', 'X'])
        self.assertEqual(meta['without_score'], 1)
        self.assertEqual(meta['future_or_today_excluded'], 1)
        self.assertEqual(rows[0]['source_blob_sha'], 'abc')

    def test_never_accepts_score_from_same_day(self):
        node = {'path': '2026/br.1.json', 'season': '2026', 'league': 'br.1', 'sha': 'sha'}
        rows, stats = r.normalize(node, {'matches': [
            {'date': '2026-11-08', 'team1': 'A', 'team2': 'B', 'score': [1, 0]},
        ]}, today=datetime.date(2026, 11, 8))
        self.assertEqual(rows, [])
        self.assertEqual(stats['future_or_today_excluded'], 1)

    def test_uses_no_network_for_tests(self):
        with patch.object(r, 'get_json', side_effect=AssertionError('Network forbidden')):
            self.assertEqual(r.completed_score({'score': {'ft': [1, 3]}}), [1, 3])


if __name__ == '__main__':
    unittest.main()
