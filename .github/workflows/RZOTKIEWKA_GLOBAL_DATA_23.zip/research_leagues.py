#!/usr/bin/env python3
"""RZOTKIEWKA GLOBAL DATA 2.3 – oddzielny import wyników historycznych.

Źródło: openfootball/football.json, CC0-1.0 (public domain).
Nie modyfikuje forecast_engine.py ani predictions.json.
Brak prognoz, brak obietnicy aktualności w czasie rzeczywistym.
"""
from __future__ import annotations

import argparse
import csv
from datetime import date, datetime, timezone
import hashlib
import io
import json
from pathlib import Path
import re
import sys
import time
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'data'
TREE_URL = 'https://api.github.com/repos/openfootball/football.json/git/trees/master?recursive=1'
RAW_BASE = 'https://raw.githubusercontent.com/openfootball/football.json/master/'
SEASONS = ('2024-25', '2025-26', '2026-27', '2024', '2025', '2026')
FILE_RE = re.compile(r'^(20\d{2}(?:-\d{2})?)/([a-z]{2,4}\.[1-9])\.json$')
SOURCE_LICENSE = 'CC0-1.0 (openfootball/football.json)'
FIELDS = ('id', 'league', 'competition', 'season', 'match_date', 'round',
          'home', 'away', 'home_goals', 'away_goals', 'outcome', 'source_path', 'source_blob_sha')
# Cele rozwoju, nie obietnica, że każde źródło udostępnia aktualny sezon.
PRIORITIES = {
    'en.1': 'Anglia – Premier League', 'en.2': 'Anglia – Championship',
    'en.3': 'Anglia – League One', 'en.4': 'Anglia – League Two',
    'de.1': 'Niemcy – Bundesliga', 'de.2': 'Niemcy – 2. Bundesliga',
    'de.3': 'Niemcy – 3. Liga', 'es.1': 'Hiszpania – La Liga',
    'es.2': 'Hiszpania – Segunda', 'it.1': 'Włochy – Serie A',
    'it.2': 'Włochy – Serie B', 'fr.1': 'Francja – Ligue 1',
    'fr.2': 'Francja – Ligue 2', 'nl.1': 'Holandia – Eredivisie',
    'pt.1': 'Portugalia – Primeira Liga', 'be.1': 'Belgia – Pro League',
    'sco.1': 'Szkocja – Premiership', 'tr.1': 'Turcja – Süper Lig',
    'gr.1': 'Grecja – Super League', 'at.1': 'Austria – Bundesliga',
    'br.1': 'Brazylia – Série A', 'ar.1': 'Argentyna – Primera División',
    'jp.1': 'Japonia – J1 League', 'us.1': 'USA – MLS',
    'mx.1': 'Meksyk – Liga MX', 'pl.1': 'Polska – Ekstraklasa',
}


def get_json(url: str, attempts: int = 3) -> dict:
    """Pobierz JSON z opóźnieniem tylko przy problemach sieciowych."""
    for attempt in range(attempts):
        req = Request(url, headers={
            'Accept': 'application/vnd.github+json' if 'api.github.com' in url else 'application/json',
            'User-Agent': 'RZOTKIEWKA-Research-Data/2.3 (github-actions; CC0)',
        })
        try:
            with urlopen(req, timeout=30) as response:
                body = response.read(8_000_001)
                if len(body) > 8_000_000:
                    raise ValueError('Plik JSON przekracza limit 8 MB')
                data = json.loads(body.decode('utf-8-sig'))
                if not isinstance(data, dict):
                    raise ValueError('Oczekiwano obiektu JSON')
                return data
        except (HTTPError, URLError, TimeoutError) as exc:
            if attempt == attempts - 1 or isinstance(exc, HTTPError) and exc.code in (401, 403, 404):
                raise RuntimeError(f'Nie udało się pobrać {url}: {exc}') from exc
            time.sleep(2 ** attempt)
    raise AssertionError('Nieosiągalne')


def discover(tree: dict, selected_seasons=SEASONS) -> list[dict]:
    if tree.get('truncated') is True:
        raise ValueError('Niekompletne drzewo GitHuba — przerwano, aby nie zgubić lig')
    nodes = tree.get('tree')
    if not isinstance(nodes, list):
        raise ValueError('Brak listy plików w odpowiedzi GitHub API')
    result = []
    for node in nodes:
        if not isinstance(node, dict) or node.get('type') != 'blob':
            continue
        match = FILE_RE.fullmatch(node.get('path', ''))
        if match and match.group(1) in selected_seasons:
            result.append({'path': node['path'], 'season': match.group(1),
                           'league': match.group(2), 'sha': node.get('sha', '')})
    if not result:
        raise ValueError('Nie znaleziono żadnych plików ligowych w wybranych sezonach')
    return sorted(result, key=lambda v: v['path'])


def completed_score(raw):
    score = raw.get('score')
    if isinstance(score, dict):
        score = score.get('ft')
    if (not isinstance(score, list) or len(score) != 2
            or any(type(n) is not int or n < 0 or n > 30 for n in score)):
        return None
    return score


def normalize(node: dict, doc: dict, *, today: date) -> tuple[list[dict], dict]:
    matches = doc.get('matches')
    if not isinstance(matches, list):
        raise ValueError(f"Brak poprawnej listy matches: {node['path']}")
    seen = {}
    rows = []
    skipped_future = 0
    skipped_pending = 0
    skipped_invalid = 0
    for item in matches:
        if not isinstance(item, dict):
            skipped_invalid += 1
            continue
        raw_date = item.get('date')
        home = item.get('team1')
        away = item.get('team2')
        if not all(isinstance(x, str) and x.strip() for x in (raw_date, home, away)):
            skipped_invalid += 1
            continue
        try:
            match_date = date.fromisoformat(raw_date)
        except ValueError:
            skipped_invalid += 1
            continue
        if match_date >= today:
            skipped_future += 1
            continue
        goals = completed_score(item)
        if goals is None:
            skipped_pending += 1
            continue
        home, away = home.strip(), away.strip()
        if home.casefold() == away.casefold():
            skipped_invalid += 1
            continue
        if len(home) > 160 or len(away) > 160:
            skipped_invalid += 1
            continue
        key = f"{node['path']}|{match_date.isoformat()}|{home.casefold()}|{away.casefold()}"
        rid = hashlib.sha256(key.encode('utf-8')).hexdigest()[:20]
        outcome = '1' if goals[0] > goals[1] else ('2' if goals[0] < goals[1] else 'X')
        row = {
            'id': rid, 'league': node['league'],
            'competition': str(doc.get('name', node['league']))[:160],
            'season': node['season'], 'match_date': match_date.isoformat(),
            'round': str(item.get('round') or '')[:100],
            'home': home, 'away': away, 'home_goals': goals[0],
            'away_goals': goals[1], 'outcome': outcome,
            'source_path': node['path'], 'source_blob_sha': node['sha'],
        }
        if rid in seen:
            if seen[rid] != row:
                raise ValueError(f"Konflikt dla meczu {rid}: {node['path']}")
            continue
        seen[rid] = row
        rows.append(row)
    stats = {'source_path': node['path'], 'league': node['league'],
             'season': node['season'], 'source_blob_sha': node['sha'],
             'completed': len(rows), 'future_or_today_excluded': skipped_future,
             'without_score': skipped_pending, 'invalid': skipped_invalid,
             'latest_match': max((r['match_date'] for r in rows), default=None)}
    # Uszkodzone rekordy nie mogą stanowić znacznej części zbioru.
    if matches and skipped_invalid > max(10, int(0.1 * len(matches))):
        raise ValueError(f"Zbyt wiele wadliwych meczów: {node['path']} ({skipped_invalid}/{len(matches)})")
    return rows, stats


def build_inventory(nodes: list[dict], stats: list[dict]) -> list[dict]:
    found = sorted({n['league'] for n in nodes} | set(PRIORITIES))
    inventory = []
    for league in found:
        src = [s for s in stats if s['league'] == league]
        inventory.append({'league': league, 'label': PRIORITIES.get(league, league),
                          'available_files': len(src), 'historical_matches': sum(x['completed'] for x in src),
                          'latest_match': max((x['latest_match'] for x in src if x['latest_match']), default=None),
                          'status': ('dane_historczne' if any(x['completed'] for x in src)
                                     else 'brak_wynikow' if src else 'brak_w_zrodle')})
    return inventory


def serialize_csv(rows):
    buff = io.StringIO(newline='')
    writer = csv.DictWriter(buff, fieldnames=FIELDS, lineterminator='\n')
    writer.writeheader()
    writer.writerows(rows)
    return buff.getvalue()


def write_atomic(path: Path, payload: str):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + '.tmp')
    tmp.write_text(payload, encoding='utf-8', newline='')
    tmp.replace(path)


def run(today: date | None = None) -> dict:
    today = today or datetime.now(timezone.utc).date()
    print('Pobieranie indeksu otwartych lig z GitHub…', flush=True)
    nodes = discover(get_json(TREE_URL))
    print(f'Plików liga/sezon: {len(nodes)}', flush=True)
    all_rows, stats = [], []
    for n, node in enumerate(nodes, 1):
        doc = get_json(RAW_BASE + node['path'])
        rows, source_stats = normalize(node, doc, today=today)
        all_rows.extend(rows)
        stats.append(source_stats)
        print(f"[{n}/{len(nodes)}] {node['path']}: {len(rows)} rozliczonych meczów", flush=True)
        time.sleep(0.25)
    # Nie zastępuj istniejących plików pustym / niepełnym importem.
    if len(all_rows) < 100 or len({r['league'] for r in all_rows}) < 5:
        raise ValueError('Za mało danych: wyniki zachowano bez zmian')
    ids = [r['id'] for r in all_rows]
    if len(ids) != len(set(ids)):
        raise ValueError('Zduplikowane ID meczów między plikami: import przerwany')
    all_rows.sort(key=lambda r: (r['match_date'], r['league'], r['id']))
    inventory = build_inventory(nodes, stats)
    summary = {
        'schema': 1, 'project': 'RZOTKIEWKA GLOBAL DATA 2.3',
        'status': 'badawcze_dane_historyczne_nie_silnik_produkcyjny',
        'license': SOURCE_LICENSE,
        'source': 'https://github.com/openfootball/football.json',
        'note': ('Wyniki historyczne nie są migawkami danych sprzed meczu. '
                 'Dane wejściowe mogą być poprawiane wstecz. '
                 'Nie są to prognozy na żywo ani dowód skuteczności modelu.'),
        'seasons_requested': list(SEASONS),
        'files_imported': len(nodes), 'league_codes_imported': len({r['league'] for r in all_rows}),
        'completed_matches': len(all_rows), 'sources': stats,
    }
    # Zapis po pełnym, udanym pobraniu wszystkich źródeł.
    write_atomic(OUT / 'research_matches.csv', serialize_csv(all_rows))
    write_atomic(OUT / 'research_leagues.json', json.dumps(inventory, ensure_ascii=False, indent=2) + '\n')
    write_atomic(OUT / 'research_sources.json', json.dumps(summary, ensure_ascii=False, indent=2) + '\n')
    print(f"GOTOWE: {len(all_rows)} meczów, {summary['league_codes_imported']} lig, "
          f"{len(nodes)} plików", flush=True)
    return summary


def main():
    parser = argparse.ArgumentParser(description='Import historycznych rozgrywek CC0 do osobnej bazy.')
    parser.add_argument('--list-priorities', action='store_true', help='Pokaż planowane ligi')
    opts = parser.parse_args()
    if opts.list_priorities:
        for code, label in PRIORITIES.items():
            print(f'{code:<8} {label}')
        return 0
    try:
        run()
    except (OSError, ValueError, RuntimeError, json.JSONDecodeError) as exc:
        print(f'BŁĄD IMPORTU: {exc}', file=sys.stderr)
        return 1
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
